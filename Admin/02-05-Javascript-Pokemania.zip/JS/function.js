// function division(dividend,divisor) {
//     if (divisor === 0) {
//         return ("You are trying to divide by 0!");
//     }
//     // if (dividend === 0) {
//     //     return ("You are trying to divide by 0!");
//     // }
//     else {
//     let result = dividend / divisor;
//     return result;
// }
// }
// ;

// document.write(division(0,5));

// // console.log(divide(4, 2));
// // console.log(divide(7, 0));
// // console.log(divide(1, 4));
// // console.log(divide(12, -3));

