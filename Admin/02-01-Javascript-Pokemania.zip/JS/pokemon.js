alert('Hello world');

var favouriteFood ='ketchup-filled Watchog Buns';
document.write(favouriteFood)