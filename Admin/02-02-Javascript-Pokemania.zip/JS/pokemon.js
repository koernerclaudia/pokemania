let PokemonList = [
    { name: 'Bulbasaur', height: 0.7, type:['grass', 'poison'], weight: 6.9},
    { name: 'Pikachu', height: 0.4, type:'electric', weight: 6},
    { name: 'Charizard', height: 1.7, type:['fire', 'flying'], weight: 90.5},
    { name: 'Squirtle', height: 0.5, type:'water', weight: 9},
    { name: 'Jigglypuff', height: 0.5, type:['normal', 'fairy'], weight: 5.5},
];